﻿using Online_Book_Shopping_System.Entity;
using System;


namespace Online_Book_Shopping_System
{
    public partial class SignInForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            UserManager userObj = new UserManager();

            string Role;
            Role = userObj.userLogIn(txtUserNameLogin.Text,txtPasswordLogin.Text);
            if(Role!=null)
            {
                //string message = "LogIn Successfull as ";
                //System.Text.StringBuilder sb = new System.Text.StringBuilder();
                //sb.Append("<script type = 'text/javascript'>");
                //sb.Append("window.onload=function(){");
                //sb.Append("alert('");
                //sb.Append(message);
                //sb.Append(Role);
                //sb.Append("')};");
                //sb.Append("</script>");
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                Response.Write("Login SucccessFul As " + Role);
            }
            else
            {
                //string message = "LogIn Failed ";
                //System.Text.StringBuilder sb = new System.Text.StringBuilder();
                //sb.Append("<script type = 'text/javascript'>");
                //sb.Append("window.onload=function(){");
                //sb.Append("alert('");
                //sb.Append(message);
                //sb.Append("')};");
                //sb.Append("</script>");
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                Response.Write("Login Failed");
            }
        }
    }
}
﻿using System.Web.UI;

namespace Online_Book_Shopping_System.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}